/*
 * tsh_helper.c - helper routines for tshlab.
 * This file does not contain extensive documentation. For documentation
 * related to usage, see the corresponding header file at tsh_helper.h.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#include "tsh_helper.h"
#include "csapp.h"
#include "sio_printf.h"

/* Async-signal-safe assertion support*/
#define sio_assert(expr) \
    ((expr) ? \
     (void) 0 : \
     __sio_assert_fail(#expr, __FILE__, __LINE__, __func__))

extern char *__progname;

void __sio_assert_fail(const char *assertion, const char *file,
                       unsigned int line, const char *function)
                       __attribute__ ((noreturn));
void __sio_assert_fail(const char *assertion, const char *file,
                       unsigned int line, const char *function) {
    Sio_fprintf(STDERR_FILENO,
                "%s: %s:%u: %s: Assertion `%s' failed.\n",
                __progname, file, line, function, assertion);
    abort();
}


// Struct used to store jobs
struct job_t
{
    pid_t pid;           // Job PID
    jid_t jid;           // Job ID [1, 2, ...] defined in tsh_helper.c
    job_state state;     // UNDEF, BG, FG, or ST
    char *cmdline;       // Command line
};


// Parsing states, used internally in parseline
typedef enum parse_state
{
    ST_NORMAL,
    ST_INFILE,
    ST_OUTFILE
} parse_state;


/* Global variables */
const char prompt[] = "tsh> ";  // Command line prompt (do not change)
bool verbose = false;           // If true, prints additional output


/* Static variables */
static bool check_block = true; // If true, check that signals are blocked
static struct job_t job_list[MAXJOBS]; // The job list
static jid_t nextjid = 1;              // Next job ID to allocate


/*
 * parseline - Parse the command line and build the argv array.
 * Not async-signal-safe.
 */
parseline_return parseline(const char *cmdline,
                           struct cmdline_tokens *token) {
    const char delims[] = " \t\r\n";    // argument delimiters (white-space)
    char *buf;                          // ptr that traverses command line
    char *next;                         // ptr to the end of the current arg
    char *endbuf;                       // ptr to end of cmdline string

    parse_state parsing_state;          // indicates if the next token is the
                                        // input or output file

    if (cmdline == NULL) {
        fprintf(stderr, "Error: command line is NULL\n");
        return PARSELINE_EMPTY;
    }

    strncpy(token->_buf, cmdline, MAXLINE_TSH);
    token->_buf[MAXLINE_TSH-1] = '\0';

    buf = token->_buf;
    endbuf = buf + strlen(buf);

    // initialize default values
    token->argc = 0;
    token->infile = NULL;
    token->outfile = NULL;

    /* Build the argv list */
    parsing_state = ST_NORMAL;

    while (buf < endbuf) {
        /* Skip the white-spaces */
        buf += strspn(buf, delims);
        if (buf >= endbuf) break;

        /* Check for I/O redirection specifiers */
        if (*buf == '<') {
            if (token->infile) {    // infile already exists
                fprintf(stderr, "Error: Ambiguous I/O redirection\n");
                return PARSELINE_ERROR;
            }
            parsing_state = ST_INFILE;
            buf++;
            continue;
        } else if (*buf == '>') {
            if (token->outfile) {   // outfile already exists
                fprintf(stderr, "Error: Ambiguous I/O redirection\n");
                return PARSELINE_ERROR;
            }
            parsing_state = ST_OUTFILE;
            buf++;
            continue;
        } else if (*buf == '\'' || *buf == '\"') {
            /* Detect quoted tokens */
            buf++;
            next = strchr(buf, *(buf - 1));
        } else {
            /* Find next delimiter */
            next = buf + strcspn(buf, delims);
        }

        if (next == NULL) {
            /* Returned by strchr(); this means that the closing
               quote was not found. */
            fprintf(stderr, "Error: unmatched %c.\n", *(buf - 1));
            return PARSELINE_ERROR;
        }

        /* Terminate the token */
        *next = '\0';

        /* Record the token as either the next argument or the i/o file */
        switch (parsing_state) {
        case ST_NORMAL:
            token->argv[token->argc] = buf;
            token->argc = token->argc + 1;
            break;
        case ST_INFILE:
            token->infile = buf;
            break;
        case ST_OUTFILE:
            token->outfile = buf;
            break;
        default:
            fprintf(stderr, "Error: Ambiguous I/O redirection\n");
            return PARSELINE_ERROR;
        }
        parsing_state = ST_NORMAL;

        /* Check if argv is full */
        if (token->argc >= MAXARGS - 1) break;

        buf = next + 1;
    }

    if (parsing_state != ST_NORMAL) { // buf ends with < or >
        fprintf(stderr, "Error: must provide file name for redirection\n");
        return PARSELINE_ERROR;
    }

    /* The argument list must end with a NULL pointer */
    token->argv[token->argc] = NULL;

    if (token->argc == 0) {  /* ignore blank line */
        return PARSELINE_EMPTY;
    }

    if ((strcmp(token->argv[0], "quit")) == 0) {        /* quit command */
        token->builtin = BUILTIN_QUIT;
    } else if ((strcmp(token->argv[0], "jobs")) == 0) { /* jobs command */
        token->builtin = BUILTIN_JOBS;
    } else if ((strcmp(token->argv[0], "bg")) == 0) {   /* bg command */
        token->builtin = BUILTIN_BG;
    } else if ((strcmp(token->argv[0], "fg")) == 0) {   /* fg command */
        token->builtin = BUILTIN_FG;
    } else {
        token->builtin = BUILTIN_NONE;
    }

    // Returns 1 if job runs on background; 0 if job runs on foreground

    if (*token->argv[(token->argc)-1] == '&') {
        token->argv[--(token->argc)] = NULL;
        return PARSELINE_BG;
    } else {
        return PARSELINE_FG;
    }
}


/*****************
 * Signal handlers
 *****************/

void sigquit_handler(int sig) {
    Sio_error("Terminating after receipt of SIGQUIT signal\n");
}



/*********************
 * End signal handlers
 *********************/



/***********************************************
 * Helper routines that manipulate the job list
 **********************************************/

/* check_blocked - Make sure that signals are blocked
 * Async-signal safe except in case of unix_error; see csapp.h
 */
static void check_blocked() {
    if (!check_block) {
        return;
    }
    sigset_t currmask;
    Sigprocmask(SIG_SETMASK, NULL, &currmask);
    if (!sigismember(&currmask, SIGCHLD)) {
        Sio_puts("WARNING: SIGCHLD not blocked\n");
    }
    if (!sigismember(&currmask, SIGINT)) {
        Sio_puts("WARNING: SIGINT not blocked\n");
    }
    if (!sigismember(&currmask, SIGTSTP)) {
        Sio_puts("WARNING: SIGTSTP not blocked\n");
    }
}

/*
 * get_job - Gets a reference to the job struct corresponding to a job ID. The job
 * struct may not necessarily be valid.
 * Async-signal-safe
 */
static struct job_t *get_job(jid_t jid) {
    sio_assert(1 <= jid && jid <= MAXJOBS);
    return &job_list[jid-1];
}

/*
 * clearjob - Clear the entries in a job struct
 * Async-signal-safe
 */
static void clearjob(struct job_t *job) {
    sio_assert(job != NULL);
    job->pid = 0;
    job->jid = 0;
    job->state = UNDEF;
}

/*
 * init_job_list - Initialize the job list
 * Not async-signal-safe
 */
void init_job_list() {
    for (jid_t jid = 1; jid <= MAXJOBS; jid++) {
        struct job_t *job = get_job(jid);
        clearjob(job);
        job->cmdline = NULL;
    }
    nextjid = 1;
}

/*
 * destroy_job_list - Destroy the job list, freeing any allocated memory
 * Not async-signal-safe (free)
 */
void destroy_job_list() {
    //check_blocked();
    for (jid_t jid = 1; jid <= MAXJOBS; jid++) {
        struct job_t *job = get_job(jid);
        clearjob(job);
        free(job->cmdline);
        job->cmdline = NULL;
    }
    nextjid = 1;
}

/*
 * maxjid - Returns largest allocated job ID
 * Async-signal-safe
 */
static jid_t maxjid() {
    for (jid_t jid = MAXJOBS; jid >= 1; jid--) {
        if (job_exists(jid)) {
            return jid;
        }
    }
    return 0;
}

/*
 * job_exists - Returns whether a job with a given jid exists
 * Async-signal-safe
 */
bool job_exists(jid_t jid) {
    check_blocked();

    if (jid < 1 || jid > MAXJOBS) {
        return false;
    }
    struct job_t *job = get_job(jid);
    return job->state != UNDEF;
}

/*
 * add_job - Add a job to the job list
 * Not async-signal-safe (realloc)
 */
jid_t add_job(pid_t pid, job_state state, const char *cmdline) {
    check_blocked();
    sio_assert((state == FG && fg_job() == 0) || state == BG || state == ST);
    sio_assert(pid > 0);
    sio_assert(cmdline != NULL);

    /* Ensure nextjid is available in job list */
    sio_assert(nextjid > 0);
    if (nextjid > MAXJOBS) {
        if (verbose) {
            fprintf(stderr, "add_job: Tried to create too many jobs\n");
        }
        return 0;
    }

    struct job_t *job = get_job(nextjid);
    sio_assert(job->state == UNDEF);

    job->jid = nextjid;
    job->pid = pid;
    job->state = state;

    /* Realloc new buffer for cmdline */
    job->cmdline = Realloc(job->cmdline, (strlen(cmdline) + 1) * sizeof(char));
    strcpy(job->cmdline, cmdline);

    if (verbose) {
        printf("Added job [%d] %d %s\n", job->jid, job->pid, job->cmdline);
    }

    nextjid++;
    sio_assert(nextjid > 0);
    return job->jid;
}

/*
 * delete_job - Delete a job by jid from the job list. Does not free memory
 * used by the cmdline buffer in the job struct, in order to ensure that
 * this function is async-signal-safe.
 * Async-signal-safe
 */
bool delete_job(jid_t jid) {
    check_blocked();

    if (!job_exists(jid)) {
        if (verbose) {
            Sio_puts("delete_job: Invalid jid\n");
        }
        return false;
    }

    struct job_t *job = get_job(jid);
    clearjob(job);

    nextjid = maxjid() + 1;
    sio_assert(nextjid > 0);
    return true;
}

/*
 * fg_job - Return JID of current foreground job, or 0 if no such job
 * Async-signal-safe
 */
jid_t fg_job() {
    check_blocked();

    for (jid_t jid = 1; jid <= MAXJOBS; jid++) {
        struct job_t *jobp = get_job(jid);
        if (jobp->state == FG) {
            return jid;
        }
    }

    if (verbose) {
        Sio_puts("fg_job: No foreground job found\n");
    }
    return 0;
}

/*
 * job_from_pid - Find a job (by PID) on the job list
 * Async-signal-safe
 */
jid_t job_from_pid(pid_t pid) {
    check_blocked();

    if (pid < 1) {
        if (verbose) {
            Sio_puts("find_job_with_pid: Invalid pid\n");
        }
        return 0;
    }

    for (jid_t jid = 1; jid <= MAXJOBS; jid++) {
        struct job_t *jobp = get_job(jid);
        if (jobp->state != UNDEF && jobp->pid == pid) {
            return jid;
        }
    }

    if (verbose) {
        Sio_puts("find_job_with_pid: Invalid pid\n");
    }
    return 0;
}


/*
 * job_get_state - Gets the state of a job, given a job ID
 * Async-signal-safe
 */
job_state job_get_state(jid_t jid) {
    check_blocked();
    sio_assert(job_exists(jid));

    struct job_t *jobp = get_job(jid);
    return jobp->state;
}

/*
 * job_set_state - Sets the state of a job
 * Async-signal-safe
 */
void job_set_state(jid_t jid, job_state state) {
    check_blocked();
    sio_assert(job_exists(jid));
    sio_assert((state == FG && fg_job() == 0) || state == BG || state == ST);

    struct job_t *jobp = get_job(jid);
    jobp->state = state;
}

/*
 * job_get_pid - Gets the process ID of a job
 * Async-signal-safe
 */
pid_t job_get_pid(jid_t jid) {
    check_blocked();
    sio_assert(job_exists(jid));

    struct job_t *jobp = get_job(jid);
    return jobp->pid;
}

/*
 * job_get_cmdline - Gets the cmdline of a job
 * Async-signal-safe
 */
const char *job_get_cmdline(jid_t jid) {
    check_blocked();
    sio_assert(job_exists(jid));

    struct job_t *jobp = get_job(jid);
    return jobp->cmdline;
}

/*
 * list_jobs - Print the job list to a file descriptor
 * Not async-signal-safe
 */
bool list_jobs(int output_fd) {
    check_blocked();
    sio_assert(output_fd >= 0);

    for (jid_t jid = 1; jid <= MAXJOBS; jid++) {
        struct job_t *jobp = get_job(jid);
        if (jobp->state == UNDEF) {
            continue;
        }

        char *status = NULL;
        switch (jobp->state) {
        case BG:
            status = "Running    ";
            break;
        case FG:
            status = "Foreground ";
            break;
        case ST:
            status = "Stopped    ";
            break;
        default:
            fprintf(stderr, "list_jobs: Internal error: jid=%d has state=%d\n",
                jid, jobp->state);
            return false;
        }

        ssize_t res = sio_fprintf(output_fd, "[%d] (%d) %s%s\n",
            jobp->jid, jobp->pid, status, jobp->cmdline);
        if (res < 0) {
            fprintf(stderr, "list_jobs: Error writing to output file\n");
            return false;
        }
    }

    return true;
}
/******************************
 * end job list helper routines
 ******************************/


/***********************
 * Other helper routines
 ***********************/

/*
 * usage - Print the usage of the tiny shell
 * Not async-signal-safe
 */
void usage(void) {
    printf("Usage: shell [-hvp]\n");
    printf("   -h   print this message\n");
    printf("   -v   print additional diagnostic information\n");
    printf("   -p   do not emit a command prompt\n");
    exit(EXIT_FAILURE);
}
